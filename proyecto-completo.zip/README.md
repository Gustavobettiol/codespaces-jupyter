# Laurabot + pipeline de contenido IA

Este repositorio contiene el bot de Telegram (`Secyposbot/`), el panel Next.js
(`apps/panel/`) y un pipeline independiente para producir imágenes, voz y clips
de una persona virtual ficticia con referencias autorizadas.

## Requisitos y costo

- Codespaces universal: CPU, 2 vCPU solicitadas y sin CUDA. El código local usa
  siempre `device="cpu"`; la inferencia GPU se ejecuta en Modal.
- Python 3.11 recomendado. Se usa PyTorch CPU en Codespaces; no se instalan
  paquetes CUDA localmente. Chatterbox fija su entorno Python a PyTorch 2.6,
  Diffusers 0.29 y Transformers 5.2; Transformers 5.2 requiere
  `huggingface_hub>=1.3`. Modal usa su propio stack GPU aislado.
- `ffmpeg` debe estar disponible en la imagen universal.
- Hugging Face token opcional para modelos públicos; guárdalo en
  **Codespaces → Settings → Secrets**, nunca en `.env` versionado.
- Los scripts Modal reciben `HF_TOKEN` como secreto efímero cuando existe en el
  entorno del Codespace; no lo imprimen ni lo guardan en el volumen.
- Modal requiere una cuenta y credenciales (`modal setup` o los secretos
  `MODAL_TOKEN_ID`/`MODAL_TOKEN_SECRET` en Codespaces Secrets). Los créditos, límites gratuitos,
  disponibilidad de GPU y condiciones pueden cambiar. Verifica el consumo en
  Modal antes de lanzar trabajos; este repositorio no puede garantizar costo
  cero ni evita cargos si el plan o los créditos no los cubren.

Los modelos descargados ocupan varios GB y se cachean en `salidas/cache/`.
Instala las dependencias solo cuando vayas a usar el pipeline:

```bash
cp .env.example .env
make setup
python -m src.cli estado
```

No cargues fotografías o audios de otra persona sin autorización expresa para
su uso en entrenamiento, generación y publicación. El consentimiento debe
quedar documentado en `dataset/<personaje>/CONSENTIMIENTO.txt` y
`voz/referencia/CONSENTIMIENTO.txt`. Usa únicamente personas adultas, reales o
ficticias, y no publiques contenido sintético haciéndolo pasar por una captura
auténtica. Los archivos de referencia y los modelos no se incluyen en Git.

## Flujo inicial

1. Edita `prompts/personaje.json` y las escenas/guiones en `prompts/`.
2. Copia 20–30 imágenes autorizadas a `dataset/<personaje>/` y agrega el
   archivo `CONSENTIMIENTO.txt` que confirma que tienes autorización para ese
   uso. No se versionan las imágenes.
3. Prepara el dataset y sus captions:

   ```bash
   python -m src.cli preparar-dataset --personaje sofia
   ```

4. Para entrenar el LoRA en Modal:

   ```bash
   modal setup
   python -m src.cli lora-entrenar --personaje sofia
   ```

5. Crea imágenes:

   ```bash
   # CPU; preview lento, sin GPU
   PERFIL=cpu python -m src.cli imgs --personaje sofia

   # GPU remota; requiere Modal configurado
   PERFIL=gpu python -m src.cli imgs --personaje sofia
   ```

6. Para generar voz, coloca una referencia limpia de 10–20 segundos en
   `voz/referencia/argentina.wav`, acompáñala con `CONSENTIMIENTO.txt` y ejecuta:

   ```bash
   python -m src.cli voz
   ```

   Chatterbox puede consumir mucha RAM y ser lento en CPU; el tiempo depende
   del host y del audio. La referencia se procesa localmente.
7. Ensambla imagen y voz en clips verticales:

   ```bash
   python -m src.cli video --imagen salidas/imagenes/A-0001.png \
     --audio salidas/voz/bienvenida.wav
   ```

8. Registra una imagen/audio/video en el catálogo:

   ```bash
   python -m src.cli catalogo --archivo salidas/videos/A-0001.mp4
   ```

`python -m src.cli todo --personaje sofia` encadena las escenas y guiones de
ejemplo. `PERFIL=cpu` genera previews locales; `PERFIL=gpu` usa Modal para
generar lotes. Siempre verifica los resultados antes de publicarlos.

## Modelos, licencias y límites

- **CPU preview:** SDXL-Lightning (pesos 4 u 8 pasos) con base SDXL. Lightning
  exige que el número de pasos coincida con el checkpoint; por eso no se fuerza
  un checkpoint de 6 pasos inexistente. Se usa 8 pasos por defecto y 768 px.
- **Producción de imágenes:** `SG161222/RealVisXL_V5.0` en Modal. Su licencia
  OpenRAIL++ no es Apache y conserva restricciones de uso; consulta los términos
  exactos antes de publicar o comercializar.
- **Voz:** `resemble-ai/chatterbox` / Chatterbox Multilingual para español.
  MIT no concede derechos sobre voces de referencia ni convierte una voz
  clonada en autorizada automáticamente.
- **Entrenamiento:** LoRA SDXL con el script de entrenamiento de Diffusers y
  `peft`, ejecutado en GPU Modal.
- **Video:** ffmpeg crea un clip vertical con movimiento lento y pista de audio.
  `src/lipsync.py` es una integración opcional y protegida para una fase
  posterior; el ensamblado básico no mueve la boca.

Los pesos, licencias de dependencias y términos de hosting deben revisarse en
cada lanzamiento. No uses FLUX.1-dev, XTTS-v2, F5-TTS ni SDXL-Turbo en este
pipeline comercial.

## Otros componentes

El bot se documenta en [`Secyposbot/README.md`](./Secyposbot/README.md). El panel
está en [`apps/panel/README.md`](./apps/panel/README.md). El pipeline de IA no
publica automáticamente al panel ni al canal de Telegram: el catálogo local
genera un índice JSON/CSV para revisión e integración posterior.

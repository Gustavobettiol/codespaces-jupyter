"""Preparación y entrenamiento LoRA."""
